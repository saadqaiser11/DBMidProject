﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MidProject.UserComponent;

namespace MidProject
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            assessment1.Hide();
            attendance1.Hide();
            clo1.Show();
            addStudent1.Hide();
            student1.Hide();
            dashboard1.Hide();
            clo1.BringToFront();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            assessment1.Hide();
            attendance1.Hide();
            clo1.Hide();
            addStudent1.Hide();
            student1.Hide();
            dashboard1.Show();
            dashboard1.BringToFront();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            assessment1.Hide();
            clo1.Hide();
            attendance1.Hide();
            addStudent1.Hide();
            student1.Hide();
            dashboard1.Show();
            dashboard1.BringToFront();
            
        }

        private void btnStudent_Click(object sender, EventArgs e)
        {
            assessment1.Hide();
            attendance1.Hide();
            clo1.Hide();
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Show();
            student1.BringToFront();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            assessment1.Hide();
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Show();
            attendance1.BringToFront();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Hide();
            assessment1.Show();
            assessment1.BringToFront();

        }

        private void button5_Click(object sender, EventArgs e)
        {
            Rubric rubric = new Rubric();
            rubric.Show();
            rubric.BringToFront();
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Hide();
            assessment1.Hide();

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Evaluation evaluation = new Evaluation();
            evaluation.Show();
            evaluation.BringToFront();
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Hide();
            assessment1.Hide();
        }

        private void clo1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ComponentSt component = new ComponentSt();
           component.Show();
           component.BringToFront();
            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Hide();
            assessment1.Hide();
        }

        private void button7_Click(object sender, EventArgs e)
        {

            addStudent1.Hide();
            dashboard1.Hide();
            student1.Hide();
            clo1.Hide();
            attendance1.Hide();
            assessment1.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
