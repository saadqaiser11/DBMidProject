﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidProject.UserComponent
{
    public partial class Student : UserControl
    {
        private string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";

        public Student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
                using (SqlConnection con = new SqlConnection(constr))
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("INSERT INTO Student VALUES (@RegistrationNumber, @FirstName, @LastName, @Contact, @Email, @Status)", con))
                    {
                        cmd.Parameters.AddWithValue("@RegistrationNumber", textBox1.Text);
                        cmd.Parameters.AddWithValue("@FirstName", textBox2.Text);
                        cmd.Parameters.AddWithValue("@LastName", textBox3.Text);
                        cmd.Parameters.AddWithValue("@Contact", textBox4.Text);
                        cmd.Parameters.AddWithValue("@Email", textBox5.Text);
                        cmd.Parameters.AddWithValue("@Status", checkBox7.Checked);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Successfully Inserted!");
                            PrintStudent();
                        }
                        else
                        {
                            MessageBox.Show("Insert operation failed or no rows affected.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }


        }
        private void PrintStudent()
        {
            string connectionString = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private void Student_Load(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            PrintStudent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                if (dataGridView1.SelectedRows.Count > 0 && dataGridView1.SelectedRows[0].Cells[0].Value != null)
                {
                    int rowIndex = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);

                    string deleteQuery = "DELETE FROM student WHERE id = @StudentId";
                    using (SqlConnection connection = new SqlConnection(constr))
                    {
                        using (SqlCommand command = new SqlCommand(deleteQuery, connection))
                        {
                            command.Parameters.AddWithValue("@StudentId", rowIndex);

                            connection.Open();
                            command.ExecuteNonQuery();

                            MessageBox.Show("Successfully Deleted!");
                            PrintStudent();
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Please select a row before attempting deletion.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }

        }




        private void label17_Click(object sender, EventArgs e)
        {

        }
    }
}
