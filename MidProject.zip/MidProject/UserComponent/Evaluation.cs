﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidProject.UserComponent
{
    public partial class Evaluation : Form
    {
        public Evaluation()
        {
            InitializeComponent();
            fillStudentCombo();
            fillAssessmentCombo();
            fillAssessmentComponent();
            fillRubricDetail();
            fillRubricID();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            saveEvaluation();
        }
        private string connectionString = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";


        private void Evalution_Load(object sender, EventArgs e)
        {

        }

        private int getStudentId()
        {
            int studentId = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Student where FirstName = @name", con);
            cmd.Parameters.AddWithValue("@name", comboBox1.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                studentId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return studentId;

        }

        private int getComponentMarks()
        {
            int Marks = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select totalMarks from AssessmentComponent where Name = @name", con);
            cmd.Parameters.AddWithValue("@name", comboBox3.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                Marks = Convert.ToInt32(reader["totalMarks"]);
            }

            con.Close();

            return Marks;
        }

        private int getRubricValue()
        {
            if (comboBox4.Text == "Unsatisfactory")
            {
                return 1;
            }
            else if (comboBox4.Text == "Fair")
            {
                return 2;
            }
            else if (comboBox4.Text == "Good")
            {
                return 3;
            }
            else { return 4; }
        }

        private int getMaxRubric()
        {
            int max = -1;

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("SELECT MAX(measurementLevel) FROM rubriclevel WHERE id = @id", con);
                cmd.Parameters.AddWithValue("@id", comboBox4.Text);

                object result = cmd.ExecuteScalar();
                if (result != DBNull.Value)  // Check for DBNull in case no result is returned
                {
                    max = Convert.ToInt32(result);
                }
                con.Close();
            }

            return max;
        }


        private int calculateObtainedMarks()
        {
            int rvalue = getRubricValue();
            int marks = getComponentMarks();
            int maxrubricValue = getMaxRubric();

            int result = (rvalue / maxrubricValue) * marks;
            return result;
        }

        private void fillStudentCombo()
        {

            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox1.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }

        private void fillAssessmentCombo()
        {
            string query = "SELECT * FROM Assessment";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox2.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }

        private void fillAssessmentComponent()
        {
            string query = "SELECT * FROM AssessmentComponent";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox3.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }


        private void fillRubricDetail()
        {
            string query = "SELECT * FROM Rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox5.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }


        private void fillRubricID()
        {
            string query = "SELECT * FROM RubricLevel";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    int id = Convert.ToInt32(reader["id"]);
                    comboBox6.Items.Add(id);

                }


                reader.Close();
                connection.Close();
            }
        }


     



     

        private void saveEvaluation()
        {
            int stdID = getStudentId();
            int assessmentComponentID = getComponentId();
            int marks = calculateObtainedMarks();

            using (SqlConnection con = new SqlConnection(connectionString))
            {

                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO StudentResult (StudentId, AssessmentComponentId, RubricMeasurementId, EvaluationDate, obtained_marks) VALUES (@stdID, @ACID, @rubicLevelId, GetDate(), @marks)", con);
                cmd.Parameters.AddWithValue("@stdID", stdID);
                cmd.Parameters.AddWithValue("@ACID", assessmentComponentID);
                cmd.Parameters.AddWithValue("@rubicLevelId", comboBox4.Text);
                cmd.Parameters.AddWithValue("@marks", marks);
                if (!checkResult())
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Saved!");
                    displayResult();
                }
                else
                {
                    con.Close();
                    MessageBox.Show("This Result Already Exist!");
                    displayResult();
                }

            }



        }



        private int getComponentId()
        {
            int compId = -1;

            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from AssessmentComponent where name = @name", con);
            cmd.Parameters.AddWithValue("@name", comboBox3.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                compId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return compId;
        }

        private void Marks()
        {

            int marks = getComponentMarks();
        }



        private void displayResult()
        {
            string query = "SELECT * FROM StudentResult where studentId = @id";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@id", getStudentId());
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

        private bool checkResult()
        {
            SqlConnection con = new SqlConnection(connectionString);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM StudentResult WHERE StudentId = @id AND AssessmentComponentId = @ACID AND RubricMeasurementId= @rid", con);
            cmd.Parameters.AddWithValue("@id", getStudentId());
            cmd.Parameters.AddWithValue("@ACID", getComponentId());
            cmd.Parameters.AddWithValue("@rid", comboBox4.Text);
            int count = (int)(cmd.ExecuteScalar());

            con.Close();

            // If count is greater than 0, it means the date exists
            return count > 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            displayResult();
        }
    }
}
