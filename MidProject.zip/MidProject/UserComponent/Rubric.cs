﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ListView;

namespace MidProject.UserComponent
{
    public partial class Rubric : Form
    {
        private string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";

        public Rubric()
        {
            InitializeComponent();
            fillCombo();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void PrintRubric()
        {
            string connectionString = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "SELECT * FROM Rubric";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                DataTable dataTable = new DataTable();
                dataTable.Load(reader);
                dataGridView1.DataSource = dataTable;
                reader.Close();
                connection.Close();
            }
        }

      private void button1_Click(object sender, EventArgs e)
      {

            int number = getCLOid();

            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO rubric (Id, Details, CLoId) VALUES (@id, @Details, @CLoId)", con);
                cmd.Parameters.AddWithValue("@id", textBox1.Text);
                cmd.Parameters.AddWithValue("@Details", textBox2.Text);
                if (number != -1)
                {
                    cmd.Parameters.AddWithValue("@CLoId", number);
                }
                else
                {
                    return;
                }
                if (!CheckIDExist())
                {
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully Inserted!");
                    PrintRubric();
                    reset();
                }
                else
                {
                    con.Close();
                    MessageBox.Show("Rubric Id already Exist");
                    reset();
                }

            }

        }
        private int getCLOid()
        {
            int CLOId = -1;

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Clo where name = @name", con);
            cmd.Parameters.AddWithValue("@name", comboBox1.Text);

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                CLOId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return CLOId;
        }
        private void reset()
        {
            textBox1.Clear();
            textBox2.Clear();
        }
        private bool CheckIDExist()
        {

            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("SELECT COUNT(*) FROM rubric where id = @id", con);
            cmd.Parameters.AddWithValue("@id", textBox1.Text);
            int count = (int)(cmd.ExecuteScalar());

            con.Close();

            // If count is greater than 0, it means the date exists
            return count > 0;
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {
            PrintRubric();
        }
        private void fillCombo()
        {
            string connectionString = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "SELECT * FROM CLO";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(1);
                    comboBox1.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }
    }
}
