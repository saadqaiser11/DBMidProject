﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MidProject.UserComponent
{
    public partial class Attendance : UserControl
    {
        public Attendance()
        {
            InitializeComponent();
            fillComboRegistration();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedItem == null)
            {
                errorProvider1.SetError(comboBox1, "It cannot be empty.");
                return;
            }
            if (comboBox2.SelectedItem == null)
            {
                errorProvider2.SetError(comboBox2, "It cannot be empty.");
                return;
            }
            saveAttendanceDate();

        }
        private void fillComboRegistration()
        {
            string connectionString = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            string query = "SELECT * FROM Student";

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand(query, connection);
                connection.Open();
                SqlDataReader reader = command.ExecuteReader();
                while (reader.Read())
                {
                    string reg = reader.GetString(5);
                    comboBox1.Items.Add(reg);

                }


                reader.Close();
                connection.Close();
            }
        }
        private void saveAttendanceDate()
        {
            ADDDate();
            int dateId = FindDateID();
            int studenId = FindStudentId();
            string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("INSERT INTO StudentAttendance (AttendanceId, StudentId, AttendanceStatus) VALUES (@attendanceId, @studentId, @status)", con);
                if (studenId != -1)
                {
                    cmd.Parameters.AddWithValue("@studentId", studenId);
                }
                else
                {
                    return;
                }
                if (dateId != -1)
                {
                    cmd.Parameters.AddWithValue("@attendanceId", dateId);
                }
                else
                {
                    return;
                }
                int number = giveNumber();
                cmd.Parameters.AddWithValue("@status", number);
                cmd.ExecuteNonQuery();
                con.Close();

            }

            MessageBox.Show("Attendance added successfully", "Saved", MessageBoxButtons.OK, MessageBoxIcon.Information);




        }
        private void resetData()
        {
            comboBox1.Items.Clear();

        }


        private int giveNumber()
        {
            if (comboBox2.Text == "Present")
            {
                return 1;
            }
            else if (comboBox2.Text == "Absent")
            {
                return 2;
            }
            else if (comboBox2.Text == "Leave")
            {
                return 3;
            }
            else { return 4; }
        }




        private void ADDDate()
        {
            string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            if (!CheckDateExist())
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO ClassAttendance (AttendanceDate) VALUES (@date)", con);
                cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker.Value));
                cmd.ExecuteNonQuery();
                con.Close();

            }

        }

        private int FindDateID()
        {
            int dateId = -1;
            string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from ClassAttendance where AttendanceDate = @date", con);
            cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker.Value));

            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                dateId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return dateId;

        }

        private bool CheckDateExist()
        {
            string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select count(*)from ClassAttendance where AttendanceDate = @date", con);
            cmd.Parameters.AddWithValue("@date", Convert.ToDateTime(dateTimePicker.Value));
            int count = (int)(cmd.ExecuteScalar());

            con.Close();

            // If count is greater than 0, it means the date exists
            return count > 0;



        }

        private int FindStudentId()
        {
            int studentId = -1;
            string constr = "Data Source=SAAD-QAISER\\SQLEXPRESS;Initial Catalog=ProjectB;Integrated Security=True";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("Select id from Student where RegistrationNumber = @reg", con);
            cmd.Parameters.AddWithValue("@reg", comboBox1.Text);
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.Read())
            {
                studentId = Convert.ToInt32(reader["id"]);
            }

            con.Close();

            return studentId;
        }

        private void delBtn_Click(object sender, EventArgs e)
        {

        }



    }
}
